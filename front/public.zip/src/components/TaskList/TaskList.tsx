import React from "react";

import { TaskListProps } from "./TaskListProps";
import TaskItem from "./TaskItem/TaskItem";

const TaskList : React.FC<TaskListProps> = (props) => {


    return (
        <div className="container flex flex-col lg mx-auto">

            { props.items.map((e) => (
                <TaskItem {...e}/>
            )) }

        </div>
    )
}

export default TaskList;
