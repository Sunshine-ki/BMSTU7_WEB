import {TaskProps} from "./TaskProps";

export interface TaskListProps {
    items: Array<TaskProps>;
}
