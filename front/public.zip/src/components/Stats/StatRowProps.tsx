export interface StatRowProps {
    id: number;
    name: string;
    count: number;
    author: string;
}
