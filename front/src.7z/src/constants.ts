export const API_URL: string = "http://localhost:5000"
